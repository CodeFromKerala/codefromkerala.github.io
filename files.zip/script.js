document.addEventListener('DOMContentLoaded', () => {
	// set year
	const yearEl = document.getElementById('year');
	if (yearEl) yearEl.textContent = new Date().getFullYear();

	const links = document.querySelectorAll('.nav-link');

	// Active link handling (bold indicates active tab)
	links.forEach(link => {
		link.addEventListener('click', () => {
			links.forEach(l => l.classList.remove('active'));
			link.classList.add('active');
		});
	});
});

